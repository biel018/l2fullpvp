##############################################
#               L2j geodata                  #
#                                            #
#       All files are integral part          # 
#          part of l2j server.               #
#                                            #
#                                            #
#         To make geodata  working           #
#          unpack all files into             #
#        /gameserver/data/geodata            #
#                 folder                     #
#                                            #
#       Current link to geodata files:       #
#     http://svn.l2jfree.com/svn/geodata     #
#                                            #
##############################################

